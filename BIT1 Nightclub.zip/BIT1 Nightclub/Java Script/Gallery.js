document.addEventListener('DOMContentLoaded', function() {
    // Enhanced Lightbox for Nightclub
    const images = document.querySelectorAll('.gallery-image');
    
    images.forEach(image => {
        image.addEventListener('click', function() {
            // Create lightbox overlay
            const lightbox = document.createElement('div');
            lightbox.id = 'nightclub-lightbox';
            lightbox.style.position = 'fixed';
            lightbox.style.top = '0';
            lightbox.style.left = '0';
            lightbox.style.width = '100%';
            lightbox.style.height = '100%';
            lightbox.style.backgroundColor = 'rgba(0,0,0,0.9)';
            lightbox.style.display = 'flex';
            lightbox.style.flexDirection = 'column';
            lightbox.style.justifyContent = 'center';
            lightbox.style.alignItems = 'center';
            lightbox.style.zIndex = '1000';
            lightbox.style.cursor = 'pointer';
            
            // Create image container
            const imgContainer = document.createElement('div');
            imgContainer.style.position = 'relative';
            imgContainer.style.maxWidth = '90%';
            imgContainer.style.maxHeight = '90%';
            
            // Create image
            const lightboxImg = document.createElement('img');
            lightboxImg.src = this.src;
            lightboxImg.alt = this.alt;
            lightboxImg.style.maxHeight = '80vh';
            lightboxImg.style.maxWidth = '100%';
            lightboxImg.style.borderRadius = '8px';
            lightboxImg.style.border = '2px solid var(--primary)';
            
            // Create caption
            const caption = document.createElement('p');
            caption.textContent = this.alt;
            caption.style.color = 'white';
            caption.style.marginTop = '1rem';
            caption.style.textAlign = 'center';
            caption.style.fontSize = '1.2rem';
            
            // Close button
            const closeBtn = document.createElement('span');
            closeBtn.textContent = '✕';
            closeBtn.style.position = 'absolute';
            closeBtn.style.top = '-15px';
            closeBtn.style.right = '-15px';
            closeBtn.style.color = 'var(--primary)';
            closeBtn.style.fontSize = '2rem';
            closeBtn.style.cursor = 'pointer';
            closeBtn.style.backgroundColor = 'black';
            closeBtn.style.borderRadius = '50%';
            closeBtn.style.width = '40px';
            closeBtn.style.height = '40px';
            closeBtn.style.display = 'flex';
            closeBtn.style.justifyContent = 'center';
            closeBtn.style.alignItems = 'center';
            
            // Add elements
            imgContainer.appendChild(lightboxImg);
            imgContainer.appendChild(closeBtn);
            lightbox.appendChild(imgContainer);
            lightbox.appendChild(caption);
            document.body.appendChild(lightbox);
            
            // Close lightbox
            closeBtn.addEventListener('click', function(e) {
                e.stopPropagation();
                document.body.removeChild(lightbox);
            });
            
            lightbox.addEventListener('click', function() {
                document.body.removeChild(lightbox);
            });
        });
    });
});