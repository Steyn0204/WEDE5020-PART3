document.addEventListener('DOMContentLoaded', function() {
    // Set current year in footer
    document.getElementById('current-year').textContent = new Date().getFullYear();
    
    // Form Validation
    const contactForm = document.getElementById('contactForm');
    if (contactForm) {
        contactForm.addEventListener('submit', function(e) {
            e.preventDefault();
            
            // Reset error messages and styles
            const errorMessages = document.querySelectorAll('.error-message');
            errorMessages.forEach(msg => msg.style.display = 'none');
            
            const inputs = document.querySelectorAll('input, select, textarea');
            inputs.forEach(input => {
                if (input.type !== 'checkbox') {
                    input.style.borderColor = '#444';
                }
            });
            
            // Validate form
            let isValid = true;
            const name = document.getElementById('name');
            const email = document.getElementById('email');
            const phone = document.getElementById('phone');
            const subject = document.getElementById('subject');
            const message = document.getElementById('message');
            
            // Name validation
            if (name.value.trim() === '') {
                document.getElementById('name-error').style.display = 'block';
                name.style.borderColor = '#ff6b6b';
                isValid = false;
            }
            
            // Email validation
            if (email.value.trim() === '' || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.value)) {
                document.getElementById('email-error').style.display = 'block';
                email.style.borderColor = '#ff6b6b';
                isValid = false;
            }
            
            // Phone validation
            if (phone.value && !/^\d{10}$/.test(phone.value)) {
                document.getElementById('phone-error').style.display = 'block';
                phone.style.borderColor = '#ff6b6b';
                isValid = false;
            }
            
            // Subject validation
            if (subject.value === '') {
                subject.style.borderColor = '#ff6b6b';
                isValid = false;
            }
            
            // Message validation
            if (message.value.trim() === '') {
                document.getElementById('message-error').style.display = 'block';
                message.style.borderColor = '#ff6b6b';
                isValid = false;
            }
            
            if (isValid) {
                // Show success message
                document.getElementById('formSuccess').style.display = 'block';
                
                // In a real application, you would send the form data to a server here
                // For example using fetch API:
                /*
                const formData = new FormData(contactForm);
                fetch('process-form.php', {
                    method: 'POST',
                    body: formData
                })
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        document.getElementById('formSuccess').style.display = 'block';
                        contactForm.reset();
                    }
                })
                .catch(error => console.error('Error:', error));
                */
                
                // Reset form
                contactForm.reset();
                
                // Hide success message after 5 seconds
                setTimeout(() => {
                    document.getElementById('formSuccess').style.display = 'none';
                }, 5000);
            }
        });
        
        // Real-time validation for phone field
        const phoneField = document.getElementById('phone');
        if (phoneField) {
            phoneField.addEventListener('input', function() {
                if (this.value && !/^\d{0,10}$/.test(this.value)) {
                    document.getElementById('phone-error').style.display = 'block';
                    this.style.borderColor = '#ff6b6b';
                } else {
                    document.getElementById('phone-error').style.display = 'none';
                    this.style.borderColor = '#444';
                }
            });
        }
    }
    
    // Mobile menu toggle functionality
    const hamburgerMenu = document.querySelector('.hamburger-menu');
    const navLinks = document.querySelector('.nav-links');
    
    if (hamburgerMenu && navLinks) {
        hamburgerMenu.addEventListener('click', function() {
            navLinks.style.display = navLinks.style.display === 'flex' ? 'none' : 'flex';
        });
    }
});